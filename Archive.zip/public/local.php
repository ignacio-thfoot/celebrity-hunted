<?php
    /*
    *  Set this to TRUE while working on VIRTUAL
    *  Set this to FALSE while working on BUILD
    */
    define( 'IS_VIRTUAL_ENV', false );

 
?>